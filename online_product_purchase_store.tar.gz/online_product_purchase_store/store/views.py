from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Product, Category, Order, OrderItem
from rest_framework.response import Response
from rest_framework.decorators import api_view
from .serializers import ProductSerializer, OrderSerializer

# 📌 View All Products
def product_list(request):
    query = request.GET.get('q', '')  # Get search query
    category_id = request.GET.get('category', '')  # Get category filter

    products = Product.objects.all()

    if query:
        products = products.filter(name__icontains=query)  # Search by product name

    if category_id:
        products = products.filter(category_id=category_id)  # Filter by category

    categories = Category.objects.all()
    return render(request, 'store/product_list.html', {'products': products, 'categories': categories})

# 📌 View Product Details
def product_detail(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    return render(request, 'store/product_detail.html', {'product': product})

# 📌 View Cart
def cart_view(request):
    cart = request.session.get('cart', {})
    cart_items = []
    total_price = 0

    for product_id, quantity in cart.items():
        product = Product.objects.get(id=product_id)
        cart_items.append({'product': product, 'quantity': quantity})
        total_price += product.price * quantity

    return render(request, 'store/cart.html', {'cart_items': cart_items, 'total_price': total_price})

# 📌 Add to Cart
def add_to_cart(request, product_id):
    cart = request.session.get('cart', {})

    if str(product_id) in cart:
        cart[str(product_id)] += 1
    else:
        cart[str(product_id)] = 1

    request.session['cart'] = cart
    return redirect('cart_view')

# 📌 Remove from Cart
def remove_from_cart(request, product_id):
    cart = request.session.get('cart', {})

    if str(product_id) in cart:
        del cart[str(product_id)]

    request.session['cart'] = cart
    return redirect('cart_view')

# 📌 Checkout
@login_required
def checkout(request):
    cart = request.session.get('cart', {})

    if not cart:
        return redirect('cart_view')

    order = Order.objects.create(user=request.user, total_price=0)
    total_price = 0

    for product_id, quantity in cart.items():
        product = Product.objects.get(id=product_id)

        # Check if there's enough stock to complete the order
        if product.stock < quantity:
            # If not enough stock, redirect to cart with a message
            return redirect('cart_view')  # You can modify this to display a specific message

        # Create the order item
        order_item = OrderItem.objects.create(order=order, product=product, quantity=quantity, price=product.price)
        total_price += product.price * quantity

        # Reduce the stock of the product
        product.stock -= quantity
        product.save()  # Save the updated product stock

    # Update total price for the order
    order.total_price = total_price
    order.save()

    request.session['cart'] = {}  # Clear cart after checkout
    return redirect('order_history')


# 📌 View Order History
@login_required
def order_history(request):
    orders = Order.objects.filter(user=request.user)
    return render(request, 'store/order_history.html', {'orders': orders})


@api_view(['GET'])
def api_product_list(request):
    products = Product.objects.all()
    serializer = ProductSerializer(products, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def api_product_detail(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    serializer = ProductSerializer(product)
    return Response(serializer.data)

@api_view(['GET'])
def api_order_list(request):
    if not request.user.is_authenticated:
        return Response({"error": "Authentication required"}, status=401)

    orders = Order.objects.filter(user=request.user)
    serializer = OrderSerializer(orders, many=True)
    return Response(serializer.data)
