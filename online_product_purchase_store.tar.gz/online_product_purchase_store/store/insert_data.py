import json
import django
import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'online_product_purchase_store.settings')
django.setup()

# Import models
from store.models import Category, Product

# Load JSON data
with open('store/init.json', 'r') as f:
    data = json.load(f)

# Insert categories
categories = {}
for category_data in data['categories']:
    category = Category.objects.create(name=category_data['name'])
    categories[category.name] = category

# Insert products
for product_data in data['products']:
    # Get the category object based on the category name
    category = categories.get(product_data['category'])

    if category:
        Product.objects.create(
            name=product_data['name'],
            description=product_data['description'],
            price=product_data['price'],
            category=category,
            stock=product_data['stock']
        )
    else:
        print(f"Category '{product_data['category']}' not found for product '{product_data['name']}'.")

print("Data inserted successfully.")
